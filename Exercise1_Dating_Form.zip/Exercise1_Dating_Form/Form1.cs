﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Markup;

namespace Exercise1_Dating_Form
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Please enter your name properly", "İnvalid Name", MessageBoxButtons.OK, MessageBoxIcon.Warning);
             
            }
            else if (comboBox1.SelectedIndex==-1)
            {
                 MessageBox.Show("Please select your prefences", "İnvalid Prefences", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                MessageBox.Show("Name: " + textBox1.Text + "\n" +
               "DOB: " + dateTimePicker1.Text + "\n" +
               "LIKES: " + comboBox1.Text, "Message", MessageBoxButtons.OK);
            }



        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
