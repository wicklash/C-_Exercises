﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercise2_BMI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        double BMI { 
            get
            {
                return double.Parse(Weight.Text) / (double.Parse(height.Text) * double.Parse(height.Text));
            }
             }
        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Your BMI is" + BMI.ToString());
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
